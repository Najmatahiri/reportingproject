"""Management for django-livereload-server"""
