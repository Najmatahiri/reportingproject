"""Management commands for django-livereload"""
