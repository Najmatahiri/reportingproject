Changelog
=========

1.2.0 (2022-04-19)
-------------------
* Switch to using lazy settings object
* Update middleware to Django's current style

1.1.0 (2022-04-15)
-------------------
* Make possible to set ``instance._change_updated_by`` option to allow not saving ``updated_by`` choice

1.0.4 (2022-01-19)
-------------------
* Don't include tests in PyPI package

1.0.3 (2022-01-15)
-------------------
* Update to Django 4.0
* Fix tests and drop support for Django versions < 2.2
